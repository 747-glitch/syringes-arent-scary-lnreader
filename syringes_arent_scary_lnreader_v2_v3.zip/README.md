# Syringes Aren't Scary — LNReader v2/v3 source

Updated for the current `lnreader-plugins` API.

## Files

- `plugins/english/syringesarentscary.ts`
- `public/static/src/en/syringesarentscary/icon.png`

## Source

https://stabbingwithasyringe.home.blog/stabbingwithasyringe-translated-works/

## Current API compatibility

The source follows the current LNReader `Plugin.PluginBase` interface:
- `popularNovels(pageNo, options)`
- `searchNovels(searchTerm, pageNo)`
- `parseNovel(novelPath)`
- `parseChapter(chapterPath)`
- `resolveUrl(path)`

It uses the current `@libs/fetch`, `@/types/plugin`, Cheerio, `defaultCover`, and `NovelStatus` imports.

Before publishing, run:

`npm install`

then:

`npm run check:plugin -- plugins/english/syringesarentscary.ts`

The current LNReader plugin repository documents Node.js 22+ and this check as the normal validation workflow.
